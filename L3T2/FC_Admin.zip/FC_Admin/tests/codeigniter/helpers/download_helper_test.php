<?php

class Download_helper_test extends CI_TestCase {

	public function test_force_download()
	{
		$this->markTestSkipped('Cant easily test');
	}

}